package com.hrm.hrmpro.util;

public enum Performance {
    Poor,Fair,Good,Better,Excellent, Extraordinary
}
