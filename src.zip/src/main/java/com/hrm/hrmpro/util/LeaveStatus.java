package com.hrm.hrmpro.util;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
