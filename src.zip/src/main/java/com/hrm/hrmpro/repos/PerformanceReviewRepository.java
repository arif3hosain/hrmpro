package com.hrm.hrmpro.repos;

import com.hrm.hrmpro.domain.PerformanceReview;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PerformanceReviewRepository extends JpaRepository<PerformanceReview, Long> {
}
